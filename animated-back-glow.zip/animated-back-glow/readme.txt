This template / effect / code has been created by George Hastings.
You can customize and check it out on its original site on the following link:
https://codepen.io/georgehastings/pen/xgwxgo

Thank you