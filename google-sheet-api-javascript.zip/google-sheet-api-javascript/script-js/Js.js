

document.getElementById('header_extension').style.display = 'none';
document.getElementById('header_profesores').style.display = 'none';



window.addEventListener('load', (event) => {
  this.inicio_values();
  this.button_copy();
  this.checked();

});

function inicio_values(){

  document.getElementById('campo').readOnly = true;
   
  document.getElementById('campo').placeholder = 'Sin conexión';
     
  document.getElementById('academica_check').click()
}



 //document.getElementById('campo').addEventListener('input', function() {
 //let valor = this.value;
   //document.getElementById('content').textContent = valor;
   //console.log(valor)
 //});
 

 //copie text

 function button_copy()
 {
  let copyText = document.querySelector(".copy-text");
  copyText.querySelector("button").addEventListener("click",function(){
    let input = copyText.querySelector("input.text");
     const text =  input.value
    input.select();
  //document.execCommand("copy");
    navigator.clipboard.writeText(text)
    copyText.classList.add("active");
    window.getSelection().removeAllRanges();
    setTimeout(function(){
      copyText.classList.remove("active");
    },2500);
  });
  

 }

 function checked(){

  let extension = document.getElementById('header_extension');
  let profesores= document.getElementById('header_profesores');
  let academica = document.getElementById('header_academica');
  let content_table_boby = document.getElementById("content_table_body");
  let = academic_check_event = document.getElementById('academica_check')
  
  const Click_academic = ()=>{

    extension.style.display = 'none';
    academica.style.display= 'block';

    profesores.style.display = 'none';
    content_table_boby.innerHTML = " ";

  }
  
  academic_check_event.addEventListener("click", Click_academic )

  let = exten_check_event = document.getElementById('extension_check')

  const Click_ext = () =>{

    academica.style.display = 'none';
    extension.style.display = "block";
    profesores.style.display = 'none';
    content_table_boby.innerHTML = " ";



  };
  
  exten_check_event.addEventListener("click", Click_ext);

  let = prof_check_event = document.getElementById('profesores_check')

  const Click_prof = () =>{

    academica.style.display = 'none';
    extension.style.display = "none";
    profesores.style.display = 'block';

    content_table_boby.innerHTML = " ";


  };
  
  prof_check_event.addEventListener("click", Click_prof);


}